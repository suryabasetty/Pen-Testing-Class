The archived folder includes the following DOCs

1: Introduction_and_Assingment : This contains brief into about sql injection, problem statement and objectives
2: sqli.php: PHP app
3. Step_By_Step_Guide.pdf