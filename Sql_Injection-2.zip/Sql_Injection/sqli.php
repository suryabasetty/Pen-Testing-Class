<?php
function sqliTest() {
    $server = "localhost"; $user = "root"; $passwd = "kali"; $db = "sql_injection";

    $sqlconnect = new mysqli($server, $user, $passwd, $db);

    if (isset($_POST['id'])) {

    $id = $_POST['id'];

	$pass = $_POST['pass'];

        $sql = "SELECT id, lastname, firstname 
        FROM users_table 
        WHERE id = '$id' 
        and pass = '$pass'";
	
	
	$res = $sqlconnect->query($sql) or die($sqlconnect->error);

	if ($res->num_rows > 0) {
		
		while ($output = $res->fetch_assoc()) {
       
		        echo print_r($output["lastname"], true);
		
                echo print_r($output["firstname"], true);
                
                echo print_r($output["id"], true);
		 
            }
           
        }

	else {
	    echo "No results found or wrong query executed";
	   
	}
     
    }
}
sqliTest();
